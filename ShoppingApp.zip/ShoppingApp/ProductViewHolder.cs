﻿using Android;
using Android.Views;
using Android.Widget;
using AndroidX.RecyclerView.Widget;

namespace ShoppingApp
{
    public class ProductViewHolder : RecyclerView.ViewHolder
    {
        public ImageView ImageView { get; private set; }
        public TextView TextViewTitle { get; private set; }
        public TextView TextViewPrice { get; private set; }
        public Button ButtonAddToCart { get; private set; }

        public ProductViewHolder(View itemView) : base(itemView)
        {
            ImageView = itemView.FindViewById<ImageView>(Resource.Id.imageView);
            TextViewTitle = itemView.FindViewById<TextView>(Resource.Id.textViewTitle);
            TextViewPrice = itemView.FindViewById<TextView>(Resource.Id.textViewPrice);
            ButtonAddToCart = itemView.FindViewById<Button>(Resource.Id.buttonAddToCart);
        }
    }
}
