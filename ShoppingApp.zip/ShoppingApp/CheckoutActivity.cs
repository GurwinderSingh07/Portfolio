﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Widget;
using AndroidX.AppCompat.App;
using AndroidX.CardView.Widget;
using Newtonsoft.Json; // Make sure to install Newtonsoft.Json via NuGet

namespace ShoppingApp
{
    [Activity(Label = "Checkout", Theme = "@style/AppTheme.NoActionBar")]
    public class CheckoutActivity : AppCompatActivity
    {
        string connectionString = "Data Source=test-cluster.cql1jkavqpwl.us-east-2.rds.amazonaws.com;Initial Catalog=shopping_db; User Id=admin; Password=admin12345";

        private CardView cardViewCash, cardViewCreditCard, cardViewDebitCard;
        private Button buttonPay;
        private EditText editTextAddress, editTextCity, editTextState;
        private string selectedPaymentMethod = string.Empty;
        private List<CartItem> _cartItems = new List<CartItem>();

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.activity_checkout);

            AndroidX.AppCompat.Widget.Toolbar toolbar = FindViewById<AndroidX.AppCompat.Widget.Toolbar>(Resource.Id.toolbar_checkout);
            SetSupportActionBar(toolbar);

            cardViewCash = FindViewById<CardView>(Resource.Id.cardViewCash);
            cardViewCreditCard = FindViewById<CardView>(Resource.Id.cardViewCreditCard);
            cardViewDebitCard = FindViewById<CardView>(Resource.Id.cardViewDebitCard);
            buttonPay = FindViewById<Button>(Resource.Id.buttonPay);
            editTextAddress = FindViewById<EditText>(Resource.Id.editTextAddress);
            editTextCity = FindViewById<EditText>(Resource.Id.editTextCity);
            editTextState = FindViewById<EditText>(Resource.Id.editTextState);

            // Initialize the card views to have a white background and black text
            InitializePaymentOptions();

            // Retrieve total price from the intent
            double totalPrice = Intent.GetDoubleExtra("TotalPrice", 0.0);
            buttonPay.Text = $"Pay: ${totalPrice:0.00}";

            // Set click listeners for payment options
            cardViewCash.Click += (s, e) => SelectPaymentOption("Cash", cardViewCash);
            cardViewCreditCard.Click += (s, e) => SelectPaymentOption("Credit Card", cardViewCreditCard);
            cardViewDebitCard.Click += (s, e) => SelectPaymentOption("Debit Card", cardViewDebitCard);

            // Set click listener for the pay button
            buttonPay.Click += (s, e) =>
            {
                SaveOrderToDatabase();
            };
        }

        private void InitializePaymentOptions()
        {
            var paymentOptions = new[] { cardViewCash, cardViewCreditCard, cardViewDebitCard };

            foreach (var cardView in paymentOptions)
            {
                cardView.SetCardBackgroundColor(Android.Graphics.Color.White);
                var textView = (TextView)cardView.GetChildAt(0);
                textView.SetTextColor(Android.Graphics.Color.Black);
            }
        }

        private void SelectPaymentOption(string paymentMethod, CardView selectedCardView)
        {
            var paymentOptions = new[] { cardViewCash, cardViewCreditCard, cardViewDebitCard };

            foreach (var cardView in paymentOptions)
            {
                cardView.SetCardBackgroundColor(
                    cardView == selectedCardView ? Android.Graphics.Color.Gray : Android.Graphics.Color.White);
                var textView = (TextView)cardView.GetChildAt(0);
                textView.SetTextColor(
                    cardView == selectedCardView ? Android.Graphics.Color.White : Android.Graphics.Color.Black);
            }
            selectedPaymentMethod = paymentMethod;
        }

        private void SaveOrderToDatabase()
        {
            var address = editTextAddress.Text;
            var city = editTextCity.Text;
            var state = editTextState.Text;

            if (string.IsNullOrEmpty(address) || string.IsNullOrEmpty(city) || string.IsNullOrEmpty(state) || string.IsNullOrEmpty(selectedPaymentMethod))
            {
                Toast.MakeText(this, "Please fill all fields and select a payment method.", ToastLength.Long).Show();
                return;
            }

            // Get the cart items
            var cartItems = GetCartItems();
            var productsJson = JsonConvert.SerializeObject(cartItems);

            using (var con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    var query = "INSERT INTO orders (address, city, state, products, payment_method) VALUES (@Address, @City, @State, @Products, @PaymentMethod)";
                    using (var cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Address", address);
                        cmd.Parameters.AddWithValue("@City", city);
                        cmd.Parameters.AddWithValue("@State", state);
                        cmd.Parameters.AddWithValue("@Products", productsJson);
                        cmd.Parameters.AddWithValue("@PaymentMethod", selectedPaymentMethod);

                        cmd.ExecuteNonQuery();
                    }

                    // Clear the cart
                    ClearCart();

                    Toast.MakeText(this, "Order placed successfully!", ToastLength.Long).Show();

                    // Optionally, navigate to another activity
                    var intent = new Intent(this, typeof(ThankYouActivity));
                    StartActivity(intent);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Order failed: {ex.Message}");
                    Console.WriteLine($"Stack Trace: {ex.StackTrace}");

                    Toast.MakeText(this, $"Order failed: {ex.Message}", ToastLength.Long).Show();
                }
            }
        }

        private List<CartItem> GetCartItems()
        {
            _cartItems.Clear(); // Clear the list before fetching new items
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "SELECT product_name, image, price FROM cart";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                _cartItems.Add(new CartItem
                                {
                                    Title = reader["product_name"].ToString(),
                                    ImageResourceId = Convert.ToInt32(reader["image"]),
                                    Price = reader["price"].ToString()
                                });
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Fetch failed: {ex.Message}");
                    Toast.MakeText(this, $"Failed to fetch cart items: {ex.Message}", ToastLength.Long).Show();
                }
            }
            return _cartItems;
        }


        private void ClearCart()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "DELETE FROM cart";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            // Console.WriteLine("Cart cleared successfully.");
                        }
                        else
                        {
                            // Console.WriteLine("No items to clear.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Clear cart failed: {ex.Message}");
                    Toast.MakeText(this, $"Failed to clear cart: {ex.Message}", ToastLength.Long).Show();
                }
            }
        }

    }
}
