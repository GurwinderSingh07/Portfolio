﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Widget;
using System;
using System.Data.SqlClient;

namespace ShoppingApp
{
    [Activity(Label = "SignupActivity")]
    public class SignupActivity : Activity
    {
        string connectionString = "Data Source=test-cluster.cql1jkavqpwl.us-east-2.rds.amazonaws.com;Initial Catalog=shopping_db; User Id=admin; Password=admin12345";

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            SetContentView(Resource.Layout.activity_signup);
            Button signupButton = FindViewById<Button>(Resource.Id.btn_signup);
            TextView signinLink = FindViewById<TextView>(Resource.Id.click_sign_in);

            EditText editFullName = FindViewById<EditText>(Resource.Id.fullnameField);
            EditText editEmail = FindViewById<EditText>(Resource.Id.emailField);
            EditText passwordField = FindViewById<EditText>(Resource.Id.passwordField);

            // Set up event handlers for the buttons
            signupButton.Click += (sender, e) => SignUpButton_Click(sender, e, editFullName.Text, editEmail.Text, passwordField.Text);
            signinLink.Click += SignInLink_Click;
        }

        private void SignUpButton_Click(object sender, EventArgs e, string fullName, string email, string password)
        {
            if (string.IsNullOrWhiteSpace(fullName))
            {
                Toast.MakeText(this, "Full name is required.", ToastLength.Long).Show();
                return;
            }

            if (string.IsNullOrWhiteSpace(email))
            {
                Toast.MakeText(this, "Email is required.", ToastLength.Long).Show();
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                Toast.MakeText(this, "Password is required.", ToastLength.Long).Show();
                return;
            }

            int? userId = InsertNewUser(fullName, email, password);
            if (userId.HasValue)
            {
                // Save userID in SharedPreferences
                var prefs = Application.Context.GetSharedPreferences("UserPrefs", FileCreationMode.Private);
                var prefEditor = prefs.Edit();
                prefEditor.PutInt("userID", userId.Value);
                prefEditor.Apply();

                // Navigate to MainActivity
                Intent intent = new Intent(this, typeof(MainActivity));
                intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask);
                StartActivity(intent);
                FinishAffinity(); // Optional: Close all other activities in the stack
            }
            else
            {
                // Show error message
                Toast.MakeText(this, "Sign-up failed. Please try again.", ToastLength.Long).Show();
            }
        }

        private void SignInLink_Click(object sender, EventArgs e)
        {
            // Clear the activity stack and navigate to LoginActivity
            Intent intent = new Intent(this, typeof(LoginActivity));
            intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask);
            StartActivity(intent);
            FinishAffinity(); // Optional: Close all other activities in the stack
        }

        private int? InsertNewUser(string fullName, string email, string password)
        {
            int? userId = null;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "INSERT INTO [user] (name, email, password) OUTPUT INSERTED.id VALUES (@FullName, @Email, @Password)";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@FullName", fullName);
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Password", password);

                        userId = (int?)cmd.ExecuteScalar();
                    }
                    con.Close();
                }
                catch (Exception ex)
                {
                    ShowAlert("Database Error", $"Insert failed: {ex.Message}");
                }
            }

            return userId;
        }

        private void ShowAlert(string title, string message)
        {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.SetTitle(title);
            dialog.SetMessage(message);
            dialog.SetPositiveButton("OK", (senderAlert, args) => {
                // Handle the OK button click event here if needed
            });
            dialog.Show();
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);
            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
