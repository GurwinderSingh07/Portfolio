﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using AndroidX.AppCompat.Widget;
using AndroidX.AppCompat.App;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace ShoppingApp
{
    [Activity(Label = "Profile", Theme = "@style/AppTheme.NoActionBar")]
    public class ProfileActivity : AppCompatActivity
    {
        string connectionString = "Data Source=test-cluster.cql1jkavqpwl.us-east-2.rds.amazonaws.com;Initial Catalog=shopping_db; User Id=admin; Password=admin12345";

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.activity_profile);

            AndroidX.AppCompat.Widget.Toolbar toolbar = FindViewById<AndroidX.AppCompat.Widget.Toolbar>(Resource.Id.toolbar_profile);
            SetSupportActionBar(toolbar);

            // Retrieve userID from SharedPreferences
            var prefs = Application.Context.GetSharedPreferences("UserPrefs", FileCreationMode.Private);
            int userId = prefs.GetInt("userID", -1);

            if (userId != -1)
            {
                LoadUserProfile(userId);
            }
            else
            {
                Toast.MakeText(this, "Failed to load user profile.", ToastLength.Long).Show();
            }

            Button logoutButton = FindViewById<Button>(Resource.Id.logoutButton);
            logoutButton.Click += (sender, e) =>
            {
                // Clear SharedPreferences and navigate to LoginActivity
                var prefEditor = prefs.Edit();
                prefEditor.Clear();
                prefEditor.Apply();

                Intent intent = new Intent(this, typeof(LoginActivity));
                intent.SetFlags(ActivityFlags.ClearTask | ActivityFlags.NewTask); // Clear the back stack
                StartActivity(intent);
                Finish();
            };
        }

        private void LoadUserProfile(int userId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "SELECT name, email FROM [user] WHERE id = @UserId";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@UserId", userId);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string fullName = reader.GetString(reader.GetOrdinal("name"));
                                string email = reader.GetString(reader.GetOrdinal("email"));

                                TextView fullNameTextView = FindViewById<TextView>(Resource.Id.fullNameTextView);
                                TextView emailTextView = FindViewById<TextView>(Resource.Id.emailTextView);

                                fullNameTextView.Text = fullName;
                                emailTextView.Text = email;
                            }
                        }
                    }
                    con.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Failed to load user profile: {ex.Message}");
                    Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                    Toast.MakeText(this, "Failed to load user profile.", ToastLength.Long).Show();
                }
            }
        }
    }
}