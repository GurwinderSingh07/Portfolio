﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Views;
using Android.Widget;
using AndroidX.AppCompat.App;
using System;

namespace ShoppingApp
{
    [Activity(Label = "Thankyou", Theme = "@style/AppTheme.NoActionBar")]
    public class ThankYouActivity : AppCompatActivity
    {
        private Button _buttonGoToHome;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.activity_thankyou);

            _buttonGoToHome = FindViewById<Button>(Resource.Id.buttonGoToHome);

            _buttonGoToHome.Click += ButtonGoToHome_Click;
        }

        private void ButtonGoToHome_Click(object sender, EventArgs e)
        {
            // Clear the activity stack and navigate to MainActivity
            Intent intent = new Intent(this, typeof(MainActivity));
            intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask);
            StartActivity(intent);
            FinishAffinity(); // Optional: Close all other activities in the stack
        }
    }
}
