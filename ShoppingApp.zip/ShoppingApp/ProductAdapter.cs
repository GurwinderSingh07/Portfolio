﻿using Android;
using Android.Content;
using Android.Util;
using Android.Views;
using Android.Widget;
using AndroidX.RecyclerView.Widget;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace ShoppingApp {
    public class ProductAdapter : RecyclerView.Adapter
    {
        string connectionString = "Data Source=test-cluster.cql1jkavqpwl.us-east-2.rds.amazonaws.com;Initial Catalog=shopping_db; User Id=admin; Password=admin12345";

        private readonly List<Product> _products;
        private readonly Context _context;

        public ProductAdapter(Context context, List<Product> products)
        {
            _context = context;
            _products = products;
        }

        public override int ItemCount => _products.Count;

        public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position)
        {
            var productViewHolder = holder as ProductViewHolder;
            var product = _products[position];

            productViewHolder.ImageView.SetImageResource(product.Image);
            productViewHolder.TextViewTitle.Text = product.Title;
            productViewHolder.TextViewPrice.Text = product.Price;


            // Handle the Add to Cart button click
            productViewHolder.ButtonAddToCart.Click += (sender, e) =>
            {
                AddToCart(product);
            };
        }

        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            var itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.item_layout, parent, false);
            return new ProductViewHolder(itemView);
        }

        private void AddToCart(Product product)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "INSERT INTO cart (product_name, image, price) VALUES (@ProductName, @Image, @Price)";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@ProductName", product.Title);
                        cmd.Parameters.AddWithValue("@Image", product.Image);
                        cmd.Parameters.AddWithValue("@Price", decimal.Parse(product.Price.TrimStart('$')));

                        cmd.ExecuteNonQuery();
                    }
                    con.Close();

                    // Show success message
                    Toast.MakeText(_context, "Item added to cart successfully!", ToastLength.Short).Show();
                }
                catch (Exception ex)
                {
                    Log.Error("ShoppingApp", ex.ToString());
                    Toast.MakeText(_context, $"Failed to add item to cart: {ex.Message}", ToastLength.Long).Show();
                }
            }
        }
    }

}


