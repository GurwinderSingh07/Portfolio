﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Google.Android.Material.Snackbar;
using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShoppingApp
{
    [Activity(Label = "LoginActivity", MainLauncher = true)]
    public class LoginActivity : Activity
    {
        string connectionString = "Data Source=test-cluster.cql1jkavqpwl.us-east-2.rds.amazonaws.com;Initial Catalog=shopping_db; User Id=admin; Password=admin12345";

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            SetContentView(Resource.Layout.activity_login);

            // Check if the user is already logged in
            var prefs = Application.Context.GetSharedPreferences("UserPrefs", FileCreationMode.Private);
            int userId = prefs.GetInt("userID", -1);

            if (userId != -1)
            {
                // User is already logged in, navigate to MainActivity
                Intent intent = new Intent(this, typeof(MainActivity));
                intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask);
                StartActivity(intent);
                FinishAffinity(); // Optional: Close all other activities in the stack
                return;
            }

            Button signInButton = FindViewById<Button>(Resource.Id.btn_sign_in);
            TextView signUpLink = FindViewById<TextView>(Resource.Id.click_sign_up);

            EditText editEmail = FindViewById<EditText>(Resource.Id.emailField);
            EditText passwordField = FindViewById<EditText>(Resource.Id.passwordField);


            // Set up event handlers for the buttons
            signInButton.Click += (sender, e) => SignInButton_Click(sender, e, editEmail.Text, passwordField.Text);
            signUpLink.Click += SignUpLink_Click;

        }

        /*private void TestDatabaseConnection()
        {
            // string connectionString = "Data Source=192.168.1.5;Initial Catalog=shopping_db; User Id=rootUser; Password=root12345";
            string connectionString = "Data Source=test-cluster.cql1jkavqpwl.us-east-2.rds.amazonaws.com;Initial Catalog=shopping_db; User Id=admin; Password=admin12345";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    Toast.MakeText(this, "Database connection successful!", ToastLength.Short).Show();
                    con.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Connection failed: {ex.Message}");
                    Console.WriteLine($"Stack Trace: {ex.StackTrace}");

                    Toast.MakeText(this, $"Database connection failed: {ex.Message}", ToastLength.Long).Show();
                }
            }
        }*/

        private void SignInButton_Click(object sender, EventArgs e, string email, string password)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                Toast.MakeText(this, "Email is required.", ToastLength.Long).Show();
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                Toast.MakeText(this, "Password is required.", ToastLength.Long).Show();
                return;
            }

            int? userId = VerifyCredentials(email, password);
            if (userId.HasValue)
            {
                // Save userID in SharedPreferences
                var prefs = Application.Context.GetSharedPreferences("UserPrefs", FileCreationMode.Private);
                var prefEditor = prefs.Edit();
                prefEditor.PutInt("userID", userId.Value);
                prefEditor.Apply();

                // Navigate to MainActivity
                Intent intent = new Intent(this, typeof(MainActivity));
                intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask);
                StartActivity(intent);
                FinishAffinity(); // Optional: Close all other activities in the stack
            }
            else
            {
                // Show error message
                Toast.MakeText(this, "Invalid email or password", ToastLength.Long).Show();
            }
        }


        private void SignUpLink_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(SignupActivity));
            intent.AddFlags(ActivityFlags.ClearTop | ActivityFlags.NewTask);
            StartActivity(intent);
            FinishAffinity(); // Optional: Close all other activities in the stack
        }


        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }

        private int? VerifyCredentials(string email, string password)
        {
            int? userId = null;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "SELECT id FROM [user] WHERE email = @Email AND password = @Password";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Password", password);

                        object result = cmd.ExecuteScalar();
                        if (result != null)
                        {
                            userId = Convert.ToInt32(result);
                        }
                    }
                    con.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Verification failed: {ex.Message}");
                    Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                }
            }

            return userId;
        }
    }
}