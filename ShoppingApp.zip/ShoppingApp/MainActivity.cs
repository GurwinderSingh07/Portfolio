﻿using System;
using Android.App;
using Android.OS;
using Android.Runtime;
using Android.Views;
using AndroidX.AppCompat.Widget;
using AndroidX.AppCompat.App;
using Google.Android.Material.Snackbar;
using AndroidX.RecyclerView.Widget;
using System.Collections.Generic;
using Android.Content;

namespace ShoppingApp
{
    [Activity(Label = "Spark Jewllery", Theme = "@style/AppTheme.NoActionBar")]
    public class MainActivity : AppCompatActivity
    {
        private RecyclerView _recyclerView;
        private RecyclerView.LayoutManager _layoutManager;
        private ProductAdapter _productAdapter;
        private List<Product> _productList;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            SetContentView(Resource.Layout.activity_main);

            Toolbar toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
            SetSupportActionBar(toolbar);

            // Initialize the RecyclerView
            _recyclerView = FindViewById<RecyclerView>(Resource.Id.recyclerView);
            // Use a GridLayoutManager with 2 columns
            _layoutManager = new GridLayoutManager(this, 2);
            _recyclerView.SetLayoutManager(_layoutManager);


            // Initialize the product list
            _productList = new List<Product>
            {
                new Product { Title = "Product 1", Price = "$10", Image = Resource.Drawable.product1 },
                new Product { Title = "Product 2", Price = "$20", Image = Resource.Drawable.product2 },
                new Product { Title = "Product 3", Price = "$30", Image = Resource.Drawable.product3 },
                new Product { Title = "Product 4", Price = "$40", Image = Resource.Drawable.product4 },
                new Product { Title = "Product 5", Price = "$50", Image = Resource.Drawable.product5 },
                new Product { Title = "Product 6", Price = "$60", Image = Resource.Drawable.product6 },
                new Product { Title = "Product 7", Price = "$70", Image = Resource.Drawable.product7 },
                new Product { Title = "Product 8", Price = "$80", Image = Resource.Drawable.product8 },
                new Product { Title = "Product 9", Price = "$90", Image = Resource.Drawable.product9 },
                new Product { Title = "Product 10", Price = "$100", Image = Resource.Drawable.product10 }
            };

            // Initialize the adapter and assign it to the RecyclerView
            _productAdapter = new ProductAdapter(this, _productList);
            _recyclerView.SetAdapter(_productAdapter);
        }

        public override bool OnCreateOptionsMenu(IMenu menu)
        {
            MenuInflater.Inflate(Resource.Menu.menu_main, menu);
            return true;
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            int id = item.ItemId;
            if (id == Resource.Id.action_cart)
            {
                var intent = new Intent(this, typeof(CartActivity));
                StartActivity(intent);
                return true;
            }
            if (id == Resource.Id.action_profile)
            {
                var intent = new Intent(this, typeof(ProfileActivity));
                StartActivity(intent);
                return true;
            }

            return base.OnOptionsItemSelected(item);
        }

        private void FabOnClick(object sender, EventArgs eventArgs)
        {
            View view = (View) sender;
            Snackbar.Make(view, "Replace with your own action", Snackbar.LengthLong)
                .SetAction("Action", (View.IOnClickListener)null).Show();
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }
	}
}
