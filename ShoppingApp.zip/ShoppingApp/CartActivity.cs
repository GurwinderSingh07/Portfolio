﻿using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using AndroidX.AppCompat.Widget;
using AndroidX.AppCompat.App;
using AndroidX.RecyclerView.Widget;
using System.Collections.Generic;
using Android.Widget;
using System.Data.SqlClient;
using System.Data;

namespace ShoppingApp
{
    [Activity(Label = "Cart", Theme = "@style/AppTheme.NoActionBar")]
    public class CartActivity : AppCompatActivity
    {
        string connectionString = "Data Source=test-cluster.cql1jkavqpwl.us-east-2.rds.amazonaws.com;Initial Catalog=shopping_db; User Id=admin; Password=admin12345";

        private RecyclerView _recyclerView;
        private CartAdapter _adapter;
        private RecyclerView.LayoutManager _layoutManager;

        private List<CartItem> _cartItems = new List<CartItem>();

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.activity_cart);

            AndroidX.AppCompat.Widget.Toolbar toolbar = FindViewById<AndroidX.AppCompat.Widget.Toolbar>(Resource.Id.toolbar_cart);
            SetSupportActionBar(toolbar);

            Button proceedButton = FindViewById<Button>(Resource.Id.proceedButton);
            proceedButton.Click += async (sender, e) =>
            {
                if (_cartItems.Count == 0)
                {
                    Toast.MakeText(this, "Your cart is empty. Please add items to the cart before proceeding.", ToastLength.Long).Show();
                }
                else
                {
                    // Calculate total price
                    double totalPrice = 0.0;
                    foreach (var item in _cartItems)
                    {
                        if (double.TryParse(item.Price.Trim('$'), out double price))
                        {
                            totalPrice += price;
                        }
                    }

                    // Proceed to the CheckoutActivity
                    var intent = new Intent(this, typeof(CheckoutActivity));
                    intent.PutExtra("TotalPrice", totalPrice);
                    StartActivity(intent);
                }
            };

            // Fetch items from the database
            FetchCartItems();

            _recyclerView = FindViewById<RecyclerView>(Resource.Id.recyclerViewCart);
            _layoutManager = new LinearLayoutManager(this);
            _recyclerView.SetLayoutManager(_layoutManager);

            _adapter = new CartAdapter(_cartItems, position =>
            {
                RemoveItemFromCart(_cartItems[position].Title); // Remove item from database
                _cartItems.RemoveAt(position);
                _adapter.NotifyItemRemoved(position);
            });

            _recyclerView.SetAdapter(_adapter);
        }

        private void FetchCartItems()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "SELECT product_name, image, price FROM cart";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                _cartItems.Add(new CartItem
                                {
                                    Title = reader["product_name"].ToString(),
                                    ImageResourceId = Convert.ToInt32(reader["image"]),
                                    Price = reader["price"].ToString()
                                });
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Fetch failed: {ex.Message}");
                    Toast.MakeText(this, $"Failed to fetch cart items: {ex.Message}", ToastLength.Long).Show();
                }
            }
        }

        private void RemoveItemFromCart(string productName)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string query = "DELETE FROM cart WHERE product_name = @ProductName";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@ProductName", productName);
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Remove failed: {ex.Message}");
                    Toast.MakeText(this, $"Failed to remove item from cart: {ex.Message}", ToastLength.Long).Show();
                }
            }
        }
    }

    public class CartItem
    {
        public int ImageResourceId { get; set; }
        public string Title { get; set; }
        public string Price { get; set; }
    }

    public class CartAdapter : RecyclerView.Adapter
    {
        private List<CartItem> _items;
        private readonly Action<int> _onRemoveClick;

        public CartAdapter(List<CartItem> items, Action<int> onRemoveClick)
        {
            _items = items;
            _onRemoveClick = onRemoveClick;
        }

        public override int ItemCount => _items.Count;

        public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position)
        {
            var viewHolder = holder as CartViewHolder;
            var item = _items[position];

            viewHolder.Title.Text = item.Title;
            viewHolder.Price.Text = item.Price;
            viewHolder.Image.SetImageResource(item.ImageResourceId); // Load image based on path or URL
            viewHolder.RemoveButton.Click += (sender, e) => _onRemoveClick(position);
        }

        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            var itemView = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.item_cart, parent, false);
            return new CartViewHolder(itemView);
        }

        public class CartViewHolder : RecyclerView.ViewHolder
        {
            public ImageView Image { get; }
            public TextView Title { get; }
            public TextView Price { get; }
            public Button RemoveButton { get; }

            public CartViewHolder(View itemView) : base(itemView)
            {
                Image = itemView.FindViewById<ImageView>(Resource.Id.imageView);
                Title = itemView.FindViewById<TextView>(Resource.Id.textViewTitle);
                Price = itemView.FindViewById<TextView>(Resource.Id.textViewPrice);
                RemoveButton = itemView.FindViewById<Button>(Resource.Id.buttonRemove);
            }
        }
    }
}
