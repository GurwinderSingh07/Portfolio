<center>
 <div class="col-md-4 box"></div>
<div class="col-md-3 box">
<a href="#" data-toggle="modal" data-target="#developers" s style="color:lightyellow;" onmouseover="this.style('color:yellow')" target="new">Created By: Project Flow Innovators</a><br><br></div>
		<!-- Modal For Developers-->
<style>
  .btn {
      box-shadow: 2px 2px 5px #000000;   
	  background-color: orange;
  .button:hover {
   background-color: blue;	   
  }
</style> 

<div class="modal fade title1" id="developers">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" style="font-family:'typo' "><span style="color:orange">Project Flow Innovators Group Members</span></h4>
		
      </div>
	  
      <div class="modal-body">
        <p>
		<div class="row">
		<div class="col-md-4">
		 <img src="image/group.png" width=100 height=100 alt="Mugunthan" class="img-rounded">
		 </div>
		 <div class="col-md-5">
		<a href="" style="color:#202020; font-family:'typo' ; font-size:18px" title="">Amanjot & Members</a>
		<h4 style="color:#202020; font-family:'typo' ;font-size:16px" class="title1">+1 (647)526-7289</h4>
		<h4 style="color:#202020;font-family:'typo' ">jotamank012003@gmail.com</h4>
		<h4 style="color:#202020;font-family:'typo' ">kaurj132873gmail.com</h4>
		<h4 style="color:#202020;font-family:'typo' ">arshdeepkaur20548@gmail.com</h4>
		<h4 style="color:#202020;font-family:'typo' ">Niagara Collage, Toronto</h4></div></div>
		</p>
      </div>
    
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->